Supplementary Data for: Evaluating protein-access gains and residual totalVI-associated contrasts in CITE-seq representation learning under distribution shift
Author: Jizhu Yang

Frozen summary tables copied unchanged from the analysis repository
(https://github.com/Jizhuy/citeseq-multimodal-reliability). No value was recomputed for this archive.

Conventions
- macro-F1 values are on held-out (internal) or target (transfer/Lawlor) cells.
- PRIMARY internal analysis = strict train-only fitting (7,573 train / 1,921 held-out HC cells).
- Files under historical_feature_transductive/ are NOT primary results.
- Bootstrap intervals are cell-level conditional intervals, not biological confidence intervals.
- Seeds, folds and run replicates are computational units; the biological unit for Lawlor is
  the donor (n = 10).
- Representation names: RNA_PCA_10 = RNA PCA; protein_PCA_10 = protein PCA;
  concat_PCA_10_10 = concatenated RNA-protein PCA; scvi_matched/scVI_matched = capacity-matched
  scVI; totalvi/totalVI = totalVI.

Files
- strict_train_only/strict_train_only_point_estimates.csv
    PRIMARY internal analysis. Held-out macro-F1 point estimates (RNA PCA, protein PCA, concat, scVI_matched, totalVI) and G_access, G_assoc, Gap_total, R_access under strict train-only fitting (7,573 train / 1,921 held-out high-confidence cells).
- strict_train_only/strict_train_only_bootstrap_summary.csv
    PRIMARY. Global cell-level conditional paired bootstrap summary (B = 10,000; seed 20260923): point estimates, bootstrap mean/median/SD, percentile 2.5/97.5 limits, and prop>0.
- strict_train_only/strict_train_only_bootstrap_global_vs_stratified.csv
    Supplementary Results SR1. Global (primary) versus class-stratified (sensitivity; seed 20260924) paired bootstrap under strict train-only fitting.
- strict_train_only/run_meta.json
    Run metadata for the strict train-only retraining (cell counts, gene/protein counts, scvi-tools and PyTorch versions, device, seed).
- information_access/information_access_sensitivity_comparison.csv
    Supplementary Results SR1b. Historical feature-transductive versus strict train-only (PRIMARY) summary. Historical G_access and Gap_total point values (+0.079, +0.113) in this file are differences of rounded F1 values; the frozen historical bootstrap output gives 0.0784 and 0.1124 (see historical_feature_transductive/bootstrap_global_vs_class_stratified.csv).
- historical_feature_transductive/bootstrap_global_vs_class_stratified.csv
    NOT PRIMARY. Historical feature-transductive internal bootstrap (deep models fit on all 10,849 cells' features), global and class-stratified. Retained only as the information-access sensitivity reported in SR1b.
- degradation/class_degradation_dirB_focus_subsets.csv
    Supplementary Results SR2. Direction B post-adaptation totalVI per-class F1 (mean over seeds) at clean versus protein corruption 0.85 for six T-cell focus subsets.
- degradation/class_degradation_dirB_totalVI_p085_delta.csv
    Supplementary Results SR2 (all classes). Same quantity for every cell type, with mean support.
- selective_prediction/selective_prediction_dirB_totalVI_cov50_vs_100.csv
    Supplementary Results SR3. Direction B totalVI at 50% versus 100% coverage (20 seeds): risk, accuracy, macro-F1, balanced accuracy.
- selective_prediction/selective_prediction_macroF1_by_coverage.csv
    Supplementary Results SR3. Accuracy, macro-F1, and balanced accuracy versus coverage for each direction and deep model (20 seeds).
- lawlor/lawlor_all_methods_donor_level_summary.csv
    Supplementary Results SR4. Donor-level (n = 10 biological donors) summary of present-class macro-F1 for all five representations.
- lawlor/lawlor_all_methods_per_donor.csv
    Supplementary Results SR4. Per-donor present-class macro-F1 for all five representations (deep models seed-averaged within donor).
- lawlor/lawlor_donor_paired_deltas_present_class.csv
    Supplementary Results SR4. Per-donor totalVI − scVI_matched paired differences.
- lawlor/lawlor_donor_summary_stats.csv
    Supplementary Results SR4. Paired-difference summary (mean, median, SD, IQR, min, max, donors favoring each model, exact two-sided sign test).
- lawlor/lawlor_simple_baseline_fold_means.csv
    Supplementary Results SR4 (continuity only). Historical fold-mean PCA aggregates; not the preferred donor-level aggregation used in main Figure 6.
- marker_channel_dropout/marker_channel_dropout_pca_development.csv
    Supplementary Results SR5. PCA-only marker-channel dropout on the development cohort; totalVI not retrained. RNA PCA in this file (0.665) is the fixed clean-data RNA PCA of this sensitivity pipeline and is not a reported result.
- marker_channel_dropout/marker_channel_dropout_meta.json
    Design metadata for SR5 (protein channels, scope, seed).
